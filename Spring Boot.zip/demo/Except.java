package com.example.demo;

public class Except {
	public static void main(String[] args) {
		 try {
			System.out.println("hgyitfgf");
			System.out.println("jbhhjdgf");
			System.out.println("10/0");
			System.out.println("khfyidf");
			System.out.println("fguisdf");
			System.out.println("fgdio");
			
			
		} catch (Exception e) {
			System.out.println( "identified" +e);
		}
		 System.out.println("hgafuyfgg");
	}
 
}
