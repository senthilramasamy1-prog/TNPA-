package com.example.demo;

public class Twotry {
	public static void main(String[] args) {
		try {
			
			System.out.println("10/0");	
		} 
		 catch (Exception e) {
			System.out.println( "identified");
			} 
		try {
			 int a [] = {10,20,30};
			System.out.println("0");
			System.out.println("1");
			System.out.println("2");
			System.out.println("3");
			System.out.println("10/0");	
		} 
		 catch (Exception e) {
			System.out.println( "identified" +e);
	
			}
		 System.out.println("hgafuyfgg");
	}
 
}
