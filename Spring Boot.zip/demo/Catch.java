package com.example.demo;

public class Catch {
	public static void main(String[] args) {
		 try {
			 int a [] = {10,20,30};
			System.out.println("0");
			System.out.println("1");
			System.out.println("2");
			System.out.println("3");
			System.out.println("10/0");	
		} 
		 
		
		 catch (ArithmeticException e1) {
				System.out.println( "identified" +e1);
			}
		 catch (ArrayIndexOutOfBoundsException e2) {
				System.out.println( "identified" + e2);
			}
		 catch (Exception e) {
				System.out.println( "identified" +e);
		 System.out.println("hgafuyfgg");
	}
	}
}
 
