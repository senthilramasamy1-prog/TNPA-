package com.example.demo;

public class Systemexit {
	public static void main(String[] args) {
		 try {
			 int a []= {10,20,30};
			System.out.println("0");
			System.out.println("1");
			System.out.println("2");
			System.out.println("3");
			
			
		} catch (Exception e) {
			System.exit(0);
			System.out.println( "identified");
		}
		 finally {
			System.out.println("");
		}
		 System.out.println(" Try catch concept");
	}
 
}
// finally executed

