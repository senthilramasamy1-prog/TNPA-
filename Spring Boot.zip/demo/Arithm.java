package com.example.demo;

public class Arithm {
	public static void main(String[] args) {
		 try {
			 int a [] = {10,20,30};
			System.out.println("0");
			System.out.println("1");
			System.out.println("2");
			System.out.println("3");
			System.out.println("10/0");
			System.out.println("fgdio");
			
			
		} 
		 catch (ArithmeticException e) {
			System.out.println( "identified" +e);
		}
		 catch (ArrayIndexOutOfBoundsException e1) {
				System.out.println( "identified" + e1);
			}
		 System.out.println("hgafuyfgg");
	}
 
}