package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringboottrainingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringboottrainingApplication.class, args);
	}

}
