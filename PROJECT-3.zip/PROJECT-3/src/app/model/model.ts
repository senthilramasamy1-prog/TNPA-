export interface Spice {
  id: number;
  name: string;
  price: number;   // price per kg
}

export interface BillItem {
  spice: Spice;
  quantity: number;
  total: number;
}



