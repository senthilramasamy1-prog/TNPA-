import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BillingService } from './service';
import { Spice } from './model/model';

@Component({
  selector: 'app-root',
  standalone:true,
  imports: [CommonModule,FormsModule,],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title ='spices-billing';
  selectedSpice!: Spice;
  quantity: number = 1;

  constructor(public billingService: BillingService) {}

  addToBill() {
    if (this.selectedSpice && this.quantity > 0) {
      this.billingService.addItem(this.selectedSpice, this.quantity);
      this.quantity = 1;
    }
  }
removeItem(index: number) {
    this.billingService.removeItem(index);
  }
  printBill() {
  window.print();
}
  today = new Date();
}

