import { Injectable } from '@angular/core';
import { Spice,BillItem } from './model/model';

@Injectable({
  providedIn: 'root',
})
export class BillingService {

  spices: Spice[] = [
    { id: 1, name: 'Turmeric', price: 200 },
    { id: 2, name: 'Chilli Powder', price: 300 },
    { id: 3, name: 'Coriander Powder', price: 180 },
    { id: 4, name: 'Pepper', price: 600 },
    { id: 5, name: 'Cumin', price: 400 },
    { id: 6, name: 'cardomom', price:1800},
  ];

  billItems: BillItem[] = [];

  addItem(spice: Spice, quantity: number) {
    const total = spice.price * quantity;

    this.billItems.push({
      spice,
      quantity,
      total
    });
  }

  removeItem(index: number) {
    this.billItems.splice(index, 1);
  }

  getGrandTotal(): number {
    return this.billItems.reduce((sum, item) => sum + item.total, 0);
  }
}
