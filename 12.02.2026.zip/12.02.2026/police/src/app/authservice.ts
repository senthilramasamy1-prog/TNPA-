import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Authservice {
  private loggedin = false;
  login(){
    this.loggedin = true;
  }
  logout(){
    this.loggedin = false;
  }
  isloggedin(){
    return this.loggedin
  }
}
