
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Authservice } from './authservice';

export const authGuard: CanActivateFn = () => {
  const auth = inject(Authservice);
  const router = inject(Router);
if (auth.isloggedin()) {
    return true; // allow access
  } else {
    router.navigate(['/login']);
    return false; // block access
  }
};
