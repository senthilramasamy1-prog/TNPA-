import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Authservice } from '../authservice';

@Component({
  selector: 'app-dashboard',
  standalone:true,
  imports: [],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {
  constructor(private auth: Authservice, private router: Router) {}
login() {
    this.auth.login();
    this.router.navigate(['/login']);
  }
}
