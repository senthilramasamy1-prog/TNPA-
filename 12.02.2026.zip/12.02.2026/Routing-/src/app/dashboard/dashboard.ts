import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Auth } from '../auth'; 
@Component({
  selector: 'app-dashboard',
  imports: [],
  standalone:true,
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard {

  constructor(
    private auth: Auth,
    private router: Router
  ) {}

  logout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
