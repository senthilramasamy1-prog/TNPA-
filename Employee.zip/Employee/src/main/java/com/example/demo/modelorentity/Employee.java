package com.example.demo.modelorentity;

public class Employee {

}
