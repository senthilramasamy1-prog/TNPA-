import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {

    @Autowired
    private MyServices service;

    // Get All Employees
    @GetMapping("/getAllEmployee")
    public List<Employee> getAllEmployee() {
        return service.getAllEmployee();
    }

    // Get Employee By Id
    @GetMapping("/getAllEmployee/{id}")
    public Employee getAllEmployeeById(@PathVariable int id) {
        return service.getEmployeeById(id);
    }

    // Add Employee
    @PostMapping("/addEmployee")
    public String addEmployee(@RequestBody Employee employee) {
        return service.addEmployee(employee);
    }

    // Update Employee
    @PutMapping("/updateEmployee/{id}")
    public String updateEmployee(@PathVariable int id,
                                 @RequestBody Employee updatedEmployee) {
        return service.updateEmployee(id, updatedEmployee);
    }

    // Delete Employee By Id
    @DeleteMapping("/deleteEmployee/{id}")
    public String deleteEmployee(@PathVariable int id) {
        return service.deleteEmployee(id);
    }

    // Delete All Employees
    @DeleteMapping("/deleteAllEmployee")
    public String deleteAllEmployee() {
        return service.deleteAllEmployees();
    }
}