package com.example.demo.Repos;

public class MyRepo {

}
