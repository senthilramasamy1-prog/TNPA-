function validateform() {
    var name = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    if (name =="")
    {
      alert("Name Field is required");  
      return false; 
    }    


    if (password =="")
    {
        alert("Password Field is required");
        return false;
    }

    else
    alert("Your Username and password are correctly filled");
    window.location.href="https://ceir.sancharsaathi.gov.in/";
    return false;
}
