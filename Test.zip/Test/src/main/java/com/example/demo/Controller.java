package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
public class Controller {

    @Autowired
    private Repository repo;

    // POST – Create Student
    @PostMapping
    public ResponseEntity<Hari> addStudent(@RequestBody Hari student) {
        return new ResponseEntity<>(repo.save(student), HttpStatus.CREATED);
    }

    // GET – Get All Students
    @GetMapping
    public ResponseEntity<List<Hari>> getAllStudents() {
        return new ResponseEntity<>(repo.findAll(), HttpStatus.OK);
    }

	

    // DELETE – Delete Student
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable int id) {
        repo.deleteById(id);
        return new ResponseEntity<>("Deleted successfully", HttpStatus.OK);
    }
}
