import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Chat {
  messages: string[] = [];

  addMessage(message: string) {
    this.messages.push(message);
  }

  getMessages() {
    return this.messages;
  }
}
