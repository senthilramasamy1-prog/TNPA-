import { Component } from '@angular/core';
import { Chat } from '../chat';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-one',
  imports: [FormsModule,CommonModule],
  templateUrl: './user-one.html',
  styleUrl: './user-one.css',
})
export class UserOne {
message: string = '';

  constructor(public chatService: Chat) {}

  sendMessage() {
    if (this.message.trim()) {
      this.chatService.addMessage('User 1: ' + this.message);
      this.message = '';
    }
  }
}
