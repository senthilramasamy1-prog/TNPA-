import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { UserOne } from "./user-one/user-one";
import { UserTwo } from "./user-two/user-two";
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, UserOne, UserTwo],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('chat-app');
}
imports: [
  FormsModule
]
