import { Component } from '@angular/core';
import { Chat } from '../chat';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-user-two',
  imports: [FormsModule,CommonModule],
  templateUrl: './user-two.html',
  styleUrl: './user-two.css',
})
export class UserTwo {
message: string = '';

  constructor(public chatService: Chat) {}

  sendMessage() {
    if (this.message.trim()) {
      this.chatService.addMessage('User 2: ' + this.message);
      this.message = '';
    }
  }
}
