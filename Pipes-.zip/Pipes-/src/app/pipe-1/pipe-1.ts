import { Component } from '@angular/core';

@Component({
  selector: 'app-pipe-1',
  imports: [],
  templateUrl: './pipe-1.html',
  styleUrl: './pipe-1.css',
})
export class Pipe1 {

}
