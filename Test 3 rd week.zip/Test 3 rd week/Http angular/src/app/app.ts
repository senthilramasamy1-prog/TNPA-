import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { HttpService } from './services/http';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, HttpClientModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class AppComponent implements OnInit {
  posts: any[] = [];
  post: any;

  constructor(private httpService: HttpService) {}

  ngOnInit() {
    // GET all posts
    this.httpService.getPosts().subscribe(res => this.posts = res);

    // GET single post
    this.httpService.getPostById(1).subscribe(res => this.post = res);
  }

  // POST method
  createPost() {
    const newPost = { title: 'New Post', body: 'Hello World', userId: 1 };
    this.httpService.createPost(newPost).subscribe(res => console.log('POST result:', res));
  }

  // PUT method
  updatePost() {
    const updatedPost = { id: 1, title: 'Updated Post', body: 'Updated body', userId: 1 };
    this.httpService.updatePost(1, updatedPost).subscribe(res => console.log('PUT result:', res));
  }

  // PATCH method
  patchPost() {
    const patchData = { title: 'Patched Title' };
    this.httpService.patchPost(1, patchData).subscribe(res => console.log('PATCH result:', res));
  }

  // DELETE method
  deletePost() {
    this.httpService.deletePost(1).subscribe(res => console.log('DELETE result:', res));
  }
}