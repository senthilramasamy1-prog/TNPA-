package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	private int id;
	private String name;
	MyAPI api;
	
	@Autowired
	public Controller(MyAPI api) {
		this.api=api;
	}
	
	@GetMapping("/hi")
	public String callHi() {
		return api.sayHi();
	}

}
