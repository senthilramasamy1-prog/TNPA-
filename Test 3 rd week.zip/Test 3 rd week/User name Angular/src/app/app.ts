import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {

  username: string = '';
  password: string = '';
  message: string = '';

  login() {
    if (this.username === 'admin' && this.password === '1234') {
      this.message = 'Login Successful';
    } else {
      this.message = 'Invalid Username or Password';
    }
  }
}