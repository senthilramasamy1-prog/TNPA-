package com.example.demo;

//Save this as Main.java

class User {
 String name;
 String email;

 // Constructor
 User(String name, String email) {
     this.name = name;
     this.email = email;
 }

 // Common method
 void login() {
     System.out.println(name + " logged in with email: " + email);
 }

 void logout() {
     System.out.println(name + " logged out.");
 }
}

//Admin class extends User
class Admin extends User {

 String role;

 Admin(String name, String email, String role) {
     super(name, email);   // Call parent constructor
     this.role = role;
 }

 void manageUsers() {
     System.out.println(name + " is managing users. Role: " + role);
 }
}

//Main class
public class Admin_User {
 public static void main(String[] args) {

     Admin admin = new Admin("Senthil", "admin@gmail.com", "Super Admin");

     // Using common methods from User
     admin.login();
     admin.manageUsers();
     admin.logout();
 }
}