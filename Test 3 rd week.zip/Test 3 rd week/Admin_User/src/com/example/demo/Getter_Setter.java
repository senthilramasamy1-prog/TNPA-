package com.example.demo;

//Save as Main.java

class Users {

 // Private variables (cannot access directly)
 private String name;
 private String email;

 // Constructor
 public Users(String name, String email) {
     this.name = name;
     this.email = email;
 }

 // Getter for name
 public String getName() {
     return name;
 }

 // Setter for name
 public void setName(String name) {
     this.name = name;
 }

 // Getter for email
 public String getEmail() {
     return email;
 }

 // Setter for email
 public void setEmail(String email) {
     this.email = email;
 }
}

public class Getter_Setter {
 public static void main(String[] args) {

     Users user = new Users("Senthil", "senthil@gmail.com");

     // Access using getter
     System.out.println("Name: " + user.getName());
     System.out.println("Email: " + user.getEmail());

     // Modify using setter
     user.setName("Murugan");
     System.out.println("Updated Name: " + user.getName());
 }
}