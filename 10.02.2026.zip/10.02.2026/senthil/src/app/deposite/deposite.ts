import { Component } from '@angular/core';

@Component({
  selector: 'app-deposite',
  imports: [],
  templateUrl: './deposite.html',
  styleUrl: './deposite.css',
})
export class Deposite {



  
}
