import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Deposite } from './deposite';

describe('Deposite', () => {
  let component: Deposite;
  let fixture: ComponentFixture<Deposite>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Deposite]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Deposite);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
