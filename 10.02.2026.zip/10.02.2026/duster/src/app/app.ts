import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  username: string = '';
  password: string = '';
  captcha: string = '';

  isLoggedIn: boolean = false;
  centerContent: string = '';

  login() {
    if (!this.username || !this.password || !this.captcha) {
      alert('All fields are mandatory!');
      return;
    }

    if (
      this.username === 'citizen' &&
      this.password === '1234' &&
      this.captcha === '5'
    ) {
      alert('Login Successful!');
      alert('Welcome Citizen\nStay alert, stay safe!');
      this.isLoggedIn = true;
      this.loadContent('home');
    } else {
      alert('Invalid Credentials or Captcha!');
    }
  }

  resetForm() {
    this.username = '';
    this.password = '';
    this.captcha = '';
  }

  loadContent(section: string) {
    if (section === 'home') {
      this.centerContent = `
        <h2>Home</h2>
        <p>Welcome to the official law enforcement portal.</p>
      `;
    } else if (section === 'about') {
      this.centerContent = `
        <h2>About Us</h2>
        <p>We serve the nation with integrity, courage, and commitment.</p>
      `;
    } else if (section === 'services') {
      this.centerContent = `
        <h2>Services</h2>
        <ul>
          <li>Crime Investigation</li>
          <li>Traffic Control</li>
          <li>Cyber Crime Unit</li>
        </ul>
      `;
    } else if (section === 'contact') {
      this.centerContent = `
        <h2>Contact</h2>
        <p>Email: support@lawagency.gov<br>Phone: 100</p>
      `;
    }
  }
}