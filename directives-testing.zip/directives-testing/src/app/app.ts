import { Component, signal } from '@angular/core';
import { Test } from "./test/test";
import { Test2 } from './test-2/test-2';
import { Test3 } from "./test-3/test-3";
import { Test4 } from "./test-4/test-4";



@Component({
  selector: 'app-root',
  imports: [Test, Test2, Test3, Test4],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('directives');
}
