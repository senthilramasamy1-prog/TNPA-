import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  imports: [],
  templateUrl: './test.html',
  styleUrl: './test.css',
})
export class Test {
 
  name="senthil";
  course="Software Development";
  fees="10000";
  venue="Anna university";
}
