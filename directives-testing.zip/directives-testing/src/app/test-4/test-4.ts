import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-test-4',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './test-4.html',
  styleUrls: ['./test-4.css'],   // ✅ styleUrls (plural)
})
export class Test4 {

  // ====== Variables ======
  role: string = 'admin';
  isLoggedIn: boolean = false;   // ✅ Added missing variable

  // ====== Methods ======
  login() {
    this.isLoggedIn = true;
  }

  logout() {
    this.isLoggedIn = false;
  }

  setRole(newRole: string) {
    this.role = newRole;
  }

}

