package Test;

public class Maths {
	
	void addition() 
	
	{
	
	}
	
}
