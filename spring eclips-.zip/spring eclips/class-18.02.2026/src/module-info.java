/**
 * 
 */
/**
 * 
 */
module calculation {
}