package com.abc;

class Father {

    void sugar() {
        System.out.println("I am having sugar");
    }

    public void bp() {
        System.out.println("Father BP");
    }
}


public class Childs extends Father {

   
    public void bp() {
        System.out.println("I am having BP");
    }

    public static void main(String[] args) {
        Childs cc = new Childs();
        cc.bp();      // overridden method
        cc.sugar();   // inherited method
    }
}


//  OOPS
// inheriance , encpsulation , polymorphism, abstraction