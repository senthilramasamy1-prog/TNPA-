package com.abc;

abstract class ATM {
	abstract void withdraw();

	abstract void deposite();

}

public class Child extends ATM{

	void withdraw() {
		System.out.println("misnisnfoasndfoasodfnasodf");
	}

	void deposite() {
		System.out.println("sdfoasdfoasjfoasjdfoasodfaosjfoas");
	}

	public static void main(String[] args) {
		Child xy = new Child();
xy.withdraw();
xy.deposite();
	}
}
