package com.abc;



public class Demo {
	
	public Demo() {
		// TODO Auto-generated constructor stub
		System.out.println(" Hellow constructor "+(2+2));
	}
	
   void add()
   {
	   System.out.println(" Hellow world "+(2+2));
   }
	
   void sub()
   {
	   System.out.println(" Hellow world "+(2-2));
   }
   
   void div()
   {
	   System.out.println(" Hellow world "+(2/2));
   }
   void mult()
   {
	   System.out.println(" Hellow world "+(2*2));
	      }
	
public static void main(String[] args) {
	Demo  cc = new Demo();
 	cc.add();
 	cc.sub();
 	cc.div();
 	cc.mult();
}
}

