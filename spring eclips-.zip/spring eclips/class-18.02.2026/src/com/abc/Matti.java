package com.abc;

public class Matti {
	
	void katti() {
		
		System.out.println("Excellent");
	}
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		Matti cc = new Matti();
			cc. katti();
	}

}
