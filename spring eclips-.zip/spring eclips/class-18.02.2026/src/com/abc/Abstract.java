package com.abc;


abstract class Ab {
    abstract void m1();
}


public class Abstract extends Ab {

   
    public void m1() {
        System.out.println("method m1");
    }

    public static void main(String[] args) {
        Abstract xy = new Abstract();
        xy.m1();
    }
}
