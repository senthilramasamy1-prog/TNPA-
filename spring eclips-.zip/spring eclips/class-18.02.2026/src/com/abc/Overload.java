package com.abc;

	// method overloading

// same name of the method with  diffi in same class		
public class Overload  {
	void m1()
	{
		System.out.println("method m1");
	}
	void m1(int a)
	{
		System.out.println("method m1");
	}
public static void main(String[] args) {
	Overload  xy = new Overload();
   xy.m1();
	
}
}
