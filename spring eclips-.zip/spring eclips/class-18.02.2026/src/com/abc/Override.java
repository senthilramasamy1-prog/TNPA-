package com.abc;

	// method overloading/ method overriding

// same name of the method with  diffi in same class	
// same nan of  a method with same parameter in ssub classs

class Abcd
{
	void m1()
	{
		System.out.println("method m1 fsdasdfsdfaro paarent clas");
	}
}

public class Override extends Abcd {
	
public static void main(String[] args) {
	Override  xy = new Override();
   xy.m1();
  
	
}
}
