
package com.abc;
public class Child1 {
  int b=8;
	   void m2(int b) 
	   {
		   System.out.println("hello "+b);
		   System.out.println("hello "+this.b);
	//	   System.out.println("hello "+a);
	   }
public static void main(String[] args) {
	Child1  xy = new Child1();
	xy.m2(3);
}
}
