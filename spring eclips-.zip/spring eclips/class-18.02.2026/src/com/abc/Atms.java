package com.abc;

abstract class ATM {
	abstract void withdraw();

	abstract void deposite();
}

abstract class Atms extends ATM {

	
	void withdraw() {
		System.out.println("money withdraw");
	}

}

public class Atm extends Atms {
	
	void deposite() {

		System.out.println("money deposite");
	}

	public static void main(String[] args) {
		Atms xy = new Atm();
		xy.withdraw();
		xy.deposite();
	}

}
