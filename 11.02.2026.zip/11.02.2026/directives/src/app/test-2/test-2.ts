import { Component } from '@angular/core';
import { CommonModule, } from '@angular/common';

@Component({
  selector: 'app-test-2',
  imports: [CommonModule],
  templateUrl: './test-2.html',
  styleUrl: './test-2.css',
})
export class Test2 {
 isloggedIn : boolean=false;
 login()
 {this.isloggedIn=true;}
 logout (){
  this.isloggedIn=false;
 }
}
