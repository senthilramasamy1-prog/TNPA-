import { Component } from '@angular/core';

@Component({
  selector: 'app-test-3',
  imports: [],
  templateUrl: './test-3.html',
  styleUrl: './test-3.css',
})
export class Test3 {

}
