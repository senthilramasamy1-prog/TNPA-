import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-header-1',
  imports: [FormsModule],
  templateUrl: './header-1.html',
  styleUrl: './header-1.css',
})
export class Header1 {
name="Tamilnadu";

isdisabled =false;

enableButton(){
  this.isdisabled=true;
}
username ="";
showalert()
{
  alert("shutup" + this.username)
}
}



